package com.example.demo;

//package com.example.userdetails;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;

public interface UserRepository extends JpaRepository<User, Long> {
    @Query("SELECT u FROM User u WHERE " +
           "(:username IS NULL OR u.username LIKE %:username%) AND " +
           "(:contactNumber IS NULL OR u.contactNumber LIKE %:contactNumber%) AND " +
           "(:cities IS NULL OR u.city IN :cities)")
    Page<User> findByFilters(
            @Param("username") String username,
            @Param("contactNumber") String contactNumber,
            @Param("cities") List<String> cities,
            Pageable pageable);
}
