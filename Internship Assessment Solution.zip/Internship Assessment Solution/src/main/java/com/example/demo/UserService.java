package com.example.demo;

//package com.example.userdetails;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class UserService {
    @Autowired
    private UserRepository userRepository;

    public Page<User> getUsers(String username, String contactNumber, List<String> cities, int page, int size) {
        return userRepository.findByFilters(username, contactNumber, cities, PageRequest.of(page, size));
    }
}
